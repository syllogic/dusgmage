<?php  
class Syllogic_CustomProductImport_Block_Adminhtml_CustomCategoryImportmeta extends Mage_Adminhtml_Block_Template {

}
