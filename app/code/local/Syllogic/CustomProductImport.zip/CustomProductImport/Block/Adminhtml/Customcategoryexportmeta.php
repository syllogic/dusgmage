<?php  
class Syllogic_CustomProductImport_Block_Adminhtml_CustomCategoryExportmeta extends Mage_Adminhtml_Block_Template {

}
