<?php  

class Syllogic_CustomProductImport_Block_Adminhtml_Customproductimportsubmenu2 extends Mage_Adminhtml_Block_Template {

}