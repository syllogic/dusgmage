<?php  
class Syllogic_CustomProductImport_Block_Adminhtml_Customproductupdateimages extends Mage_Adminhtml_Block_Template {

}