<?php  

class Mks_Responsivebannerslider_Block_Adminhtml_Responsivebannersliderbackend extends Mage_Adminhtml_Block_Template {

}