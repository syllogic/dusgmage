<?php  

class Mks_Bannerslider_Block_Adminhtml_Bannersliderbackend extends Mage_Adminhtml_Block_Template {

}